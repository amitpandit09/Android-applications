package com.example.hw3;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.*;
import java.text.SimpleDateFormat;

interface handleTrackList{
    public void fetchListOfTracks(ArrayList<Track> tracks);
}

public class SearchAPI extends AsyncTask<String,Void, ArrayList<Track>> {
    handleTrackList h1;

    SearchAPI(handleTrackList hd){
        this.h1=hd;
    }

    @Override
    protected ArrayList<Track> doInBackground(String... strings) {
        HttpURLConnection connection = null;
        ArrayList<Track> result = new ArrayList<>();
        try {
            URL url = new URL(strings[0]);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                JSONObject root = new JSONObject(json);
                Log.d("demo", "root len" + root.length());
                JSONArray results = root.getJSONArray("results");
                for (int i = 0; i < results.length(); i++) {
                    JSONObject resultsJson = results.getJSONObject(i);
                    Track res = new Track();
                    res.artistName = resultsJson.getString("artistName");
                    res.collectionName = resultsJson.getString("collectionName");
                    res.collectionPrice = resultsJson.getDouble("collectionPrice");
                    res.primaryGenreName = resultsJson.getString("primaryGenreName");
                    res.trackPrice = resultsJson.getDouble("trackPrice");
                    res.trackName = resultsJson.getString("trackName");
                    res.trackURL = resultsJson.getString("artworkUrl100");

                    //extracting the date in suitable format
                    String tempDate = resultsJson.getString("releaseDate");
                    res.date = processDate(tempDate);

                    result.add(res);
                }
                return result;
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(ArrayList<Track> tracks) {
        super.onPostExecute(tracks);
        h1.fetchListOfTracks(tracks);
    }

    public Date processDate(String date){
        Date dateTemp = null;
        String[] mainList = date.split("-");
        String[] dateList = mainList[2].split("T");

        String extractedDate = mainList[1]+"-"+dateList[0]+"-"+mainList[0];
        try {
            dateTemp=new SimpleDateFormat("MM-dd-yyyy").parse(extractedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return  dateTemp;
    }
}
