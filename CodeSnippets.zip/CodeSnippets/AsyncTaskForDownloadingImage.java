package com.example.hw3;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.BufferedReader;
import java.net.HttpURLConnection;


/*
 Asyn task to download image
 Input as String API URL
 Output as Bitmap image
 */

interface handleData{
    public void downloadImage(Bitmap image);
}
public class downloadImage extends AsyncTask<String,Void, Bitmap> {
    handleData h1;

    downloadImage(handleData hd){
        this.h1=hd;
    }

    @Override
    protected Bitmap doInBackground(String... strings) {
        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        Bitmap myBitmap = getImageBitmap(strings[0]);
        return myBitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        h1.downloadImage(bitmap);
    }

    Bitmap getImageBitmap(String... strings) {
        Bitmap myBitmap = null;
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return myBitmap;
    }

}
