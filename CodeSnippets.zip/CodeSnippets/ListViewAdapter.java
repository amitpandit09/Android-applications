package com.example.hw3;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.support.annotation.NonNull;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.List;

public class TrackAdapter extends ArrayAdapter<Track> {


    public static String TRACK_KEY = "TRACK";
    public TrackAdapter(Context context, int resource, List<Track> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView,ViewGroup parent) {
        Track track = getItem(position);
        ViewHolder viewHolder;
        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.trackview, parent, false);

            viewHolder = new ViewHolder();
            viewHolder.trackName = (TextView) convertView.findViewById(R.id.trackresult);
            viewHolder.artistName = (TextView) convertView.findViewById(R.id.artistresult);
            viewHolder.trackPrice = (TextView) convertView.findViewById(R.id.priceresult);
            viewHolder.date = (TextView) convertView.findViewById(R.id.date_result);
            convertView.setTag(viewHolder);

        }else{
            viewHolder = (ViewHolder)convertView.getTag();
        }
        viewHolder.trackName.setText(track.trackName);
        viewHolder.artistName.setText(track.artistName);
        viewHolder.trackPrice.setText(Double.toString(track.trackPrice));
        viewHolder.date.setText(new SimpleDateFormat("MM-dd-yyyy").format(track.date));

        return convertView;
    }

    private static class ViewHolder{
        TextView trackName;
        TextView trackPrice;
        TextView artistName;
        TextView date;
    }
}
