package com.example.hw3;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


/*
        RecyclerViewAdapter
 */
public class TrackRAdapter extends RecyclerView.Adapter<TrackRAdapter.ViewHolder> {

    public static String TRACK_KEY = "TRACK";
    ArrayList<Track> mData;

    public TrackRAdapter(ArrayList<Track> tracksList) {
        this.mData = tracksList;
    }

    @NonNull
    @Override
    public TrackRAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.trackview, viewGroup, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull TrackRAdapter.ViewHolder viewHolder, int i) {
        Track track = mData.get(i);
        viewHolder.trackName.setText(track.trackName);
        viewHolder.artistName.setText(track.artistName);
        viewHolder.trackPrice.setText(Double.toString(track.trackPrice));
        viewHolder.date.setText(new SimpleDateFormat("MM-dd-yyyy").format(track.date));
        viewHolder.track = track;
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView trackName;
        TextView trackPrice;
        TextView artistName;
        TextView date;
        Track track;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);

            trackName = itemView.findViewById(R.id.trackresult);
            trackPrice = itemView.findViewById(R.id.priceresult);
            artistName = itemView.findViewById(R.id.artistresult);
            date = itemView.findViewById(R.id.date_result);

                        itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Context context = itemView.getContext();
                                Intent i=new Intent(context,TrackDetails.class);
                                i.putExtra(TRACK_KEY,track);
                                context.startActivity(i);
                                Log.d("demo","item click"+track.trackName);

                            }
                        });
        }
    }
}

