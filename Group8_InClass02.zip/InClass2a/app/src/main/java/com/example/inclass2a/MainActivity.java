package com.example.inclass2a;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    EditText weight;
    EditText heightFeet;
    EditText heightInch;
    Button button;
    TextView bmiValue;
    TextView bmiStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BMI Calculator");

        weight = findViewById(R.id.weightValue);
        heightFeet = findViewById(R.id.heightFeetValue);
        heightInch = findViewById(R.id.heightInchValue);
        bmiValue = findViewById(R.id.bmiValue);
        bmiStatus = findViewById(R.id.bmiStatus);

        Button btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String wVal = weight.getText().toString();
                String hFeetVal = heightFeet.getText().toString();
                String hInchVal = heightInch.getText().toString();

                if (!wVal.equals("") && !hFeetVal.equals("") && !hInchVal.equals("")){
                    float wFloatVal = Float.parseFloat(wVal);
                    float hFeetFloatVal = Float.parseFloat(hFeetVal);
                    float hInchFloatVal = Float.parseFloat(hInchVal);
                    float bmi = ((wFloatVal)/(((hFeetFloatVal*12)+hInchFloatVal)*((hFeetFloatVal*12)+hInchFloatVal)))*703;
                   // DecimalFormat formatedBMI = new DecimalFormat("#.#");
                   // Double finalBMI= Double.parseDouble(formatedBMI);

                    if (wFloatVal>0 && ((hFeetFloatVal*12)+hInchFloatVal)>0){

                        BigDecimal formattedBMI = new BigDecimal(bmi);
                        formattedBMI = formattedBMI.setScale(1, BigDecimal.ROUND_HALF_UP);
                        double finalBMI = formattedBMI.doubleValue();

                        if (hInchFloatVal>=0 && hInchFloatVal<13){

                            bmiValue.setText("Your BMI is : "+finalBMI);

                            if (finalBMI>=0 && finalBMI<18.5)
                                bmiStatus.setText("BMI Status: UnderWeight");
                            else if (finalBMI>=18.5 && finalBMI<=24.9)
                                bmiStatus.setText("BMI Status: Normal");
                            else if (finalBMI>=25 && finalBMI<=29.9)
                                bmiStatus.setText("BMI Status: OverWeight");
                            else
                                bmiStatus.setText("BMI Stauts: Obese");
                            Toast.makeText(getApplicationContext(),"BMI Calculated",Toast.LENGTH_SHORT).show();
                        }
                        else{
                            heightInch.setError("enter inch between 0-12");
                        }

                    }
                    else{
                            if(wFloatVal == 0)
                                weight.setError("Weight Can't be '0'");
                            if(((hFeetFloatVal*12)+hInchFloatVal)== 0){
                                if(hFeetFloatVal==0 && hInchFloatVal==0){
                                    heightFeet.setError("Height can't be '0'");
                                    heightInch.setError("Height can't be '0'");
                                }
                            }
                    }
                }
                else {
                    if (wVal.equals(""))
                        weight.setError("Empty!");
                    if(hFeetVal.equals(""))
                        heightFeet.setError("Empty!");
                    if (hInchVal.equals(""))
                        heightInch.setError("Empty!");
                }

            }
        });

    }
}
