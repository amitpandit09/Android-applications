package com.example.inclass03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Below class is used to display the profile data for student
 * Author : Amit Pandit
 */
public class DisplayMyProfile extends AppCompatActivity {
    TextView studentName;
    TextView department;
    TextView studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_my_profile);
        setTitle("Display Profile");

        Student stud = (Student)getIntent().getExtras().getSerializable(MainActivity.STUDENT_KEY);

        String sName = stud.firstName+" "+stud.lastName;
        String sDepartment = stud.department;
        String sId = String.valueOf(stud.studentId);
        int imageId = stud.imageId;

        studentName = findViewById(R.id.studentTextValue);
        department = findViewById(R.id.departmentValue);
        studentId = findViewById(R.id.sidValue);

        studentName.setText(sName);
        department.setText(sDepartment);
        studentId.setText(sId);
        if(imageId == 1)
        {
            ImageView imageID = findViewById(R.id.imageView2);
            imageID.setImageResource(R.drawable.avatar_f_1);
        }
        else if(imageId == 2){
            ImageView imageID = findViewById(R.id.imageView2);
            imageID.setImageResource(R.drawable.avatar_f_2);
        }
        else if(imageId ==3){
            ImageView imageID = findViewById(R.id.imageView2);
            imageID.setImageResource(R.drawable.avatar_f_3);
        }
        else if(imageId ==4){
            ImageView imageID = findViewById(R.id.imageView2);
            imageID.setImageResource(R.drawable.avatar_m_1);
        }
        else if(imageId ==5){
            ImageView imageID = findViewById(R.id.imageView2);
            imageID.setImageResource(R.drawable.avatar_m_2);
        }
        else if(imageId ==6){
            ImageView imageID = findViewById(R.id.imageView2);
            imageID.setImageResource(R.drawable.avatar_m_3);
        }

        findViewById(R.id.editButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
