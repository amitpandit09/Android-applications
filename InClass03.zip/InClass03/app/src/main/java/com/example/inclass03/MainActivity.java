package com.example.inclass03;

import android.annotation.SuppressLint;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.content.Intent;
import android.widget.TextView;

/**
 * Below is the Main Class where all the main logic has been implemented and communication between different activities.
 * Author : Nitin H.
 */
public class MainActivity extends AppCompatActivity {

    EditText firstName;
    EditText lastName;
    EditText studentID;
    RadioGroup department;
    RadioButton rd;
    TextView errorV;
    int value;

    public static final int REQ_CODE = 100;
    public static final String VALUE_KEY = "value";
    public static String STUDENT_KEY = "STUDENT";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("My Profile");

        // below textview object is for displaying any negavtive validation errors
        errorV = findViewById(R.id.errorView);

        // Below method is used to pass the intent to select avatar activity and pass back the selected avatar ID.
        findViewById(R.id.myAvatarImage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myAvatarSelection = new Intent(MainActivity.this,SelectAvatar.class);
                startActivityForResult(myAvatarSelection,REQ_CODE);
            }
        });

        // below is the method used to get the selected radio button from the radio groups for getting department value.

        department = findViewById(R.id.radioGroup);
        department.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                rd = findViewById(checkedId);
                Log.d("demo","Deparment selected is "+rd.getText().toString());
            }

        });



         // Below method is for handling on click event for SAVE button.
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {

                firstName = findViewById(R.id.firstName);
                lastName = findViewById(R.id.lastName);
                studentID = findViewById(R.id.studentID);

                String fName= firstName.getText().toString();
                String lName= lastName.getText().toString();
                String sID= studentID.getText().toString();

                //validating if the fields are empty or not
                //validating if the student ID provided is or 9 digit integers only
                if(!fName.isEmpty() && !lName.isEmpty() && !sID.isEmpty() && !rd.getText().toString().isEmpty()) {
                    if (sID.length() == 9) {

                        //creating a student object
                        Student student = new Student(fName, lName, Integer.parseInt(sID), rd.getText().toString(), value);

                        //creating intent to pass the data to display activity
                        Intent display = new Intent(MainActivity.this, DisplayMyProfile.class);
                        display.putExtra(STUDENT_KEY, student);
                        startActivity(display);

                    } else {
                        errorV.setError("Student ID must be 9 digit integer");
                        errorV.setText("Student ID must be 9 digit integer");
                    }
                }else{
                    errorV.setError("One of the fields is empty");
                    errorV.setText("One of the fields is empty");
                }


            }
        });
}
    // below method is used to validate the data passed backed by the select avatar activity
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQ_CODE){

            if(resultCode == RESULT_OK){

                try {
                    value = data.getExtras().getInt(VALUE_KEY);
                }catch (NullPointerException e){
                    Log.d("exception","No data recieved back from display activity"+e.getMessage());
                }

                Log.d("demo","Value recieved is "+value);

                if(value == 1)
                {
                    ImageView imageID = findViewById(R.id.myAvatarImage);
                    imageID.setImageResource(R.drawable.avatar_f_1);
                }
                else if(value == 2){
                    ImageView imageID = findViewById(R.id.myAvatarImage);
                    imageID.setImageResource(R.drawable.avatar_f_2);
                }
                else if(value ==3){
                    ImageView imageID = findViewById(R.id.myAvatarImage);
                    imageID.setImageResource(R.drawable.avatar_f_3);
                }
                else if(value ==4){
                    ImageView imageID = findViewById(R.id.myAvatarImage);
                    imageID.setImageResource(R.drawable.avatar_m_1);
                }
                else if(value ==5){
                    ImageView imageID = findViewById(R.id.myAvatarImage);
                    imageID.setImageResource(R.drawable.avatar_m_2);
                }
                else if(value ==6){
                    ImageView imageID = findViewById(R.id.myAvatarImage);
                    imageID.setImageResource(R.drawable.avatar_m_3);
                }

            }
            else if(requestCode == RESULT_CANCELED){
                Log.d("demo","No value recieved");
            }
        }
    }


}
