package com.example.inclass03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

/**
 * Below class is used to select avatar and pass back the selected avatar ID to main profile builder class.
 * Author : Amit Pandit
 */
public class SelectAvatar extends AppCompatActivity {

    ImageView myAvatar;
    int value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_avatar);
        setTitle("Select Avatar");


        //first
        findViewById(R.id.avatarf1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = 1;
                if(value == 0 ){
                    setResult(RESULT_CANCELED);
                }else{
                    Intent intent=new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY,value);
                    setResult(RESULT_OK,intent);
                }
                finish();
            }
        });

        //second
        findViewById(R.id.avatarf2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = 2;
                if(value == 0 ){
                    setResult(RESULT_CANCELED);
                }else{
                    Intent intent=new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY,value);
                    setResult(RESULT_OK,intent);
                }
                finish();
            }
        });

        //third
        findViewById(R.id.avatarf3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = 3;
                if(value == 0 ){
                    setResult(RESULT_CANCELED);
                }else{
                    Intent intent=new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY,value);
                    setResult(RESULT_OK,intent);

                }
                finish();
            }
        });

        //fourth
        findViewById(R.id.avatarm1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = 4;
                if(value == 0 ){
                    setResult(RESULT_CANCELED);
                }else{
                    Intent intent=new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY,value);
                    setResult(RESULT_OK,intent);

                }
                finish();
            }
        });

        //fifth
        findViewById(R.id.avatarm2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = 5;
                if(value == 0 ){
                    setResult(RESULT_CANCELED);
                }else{
                    Intent intent=new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY,value);
                    setResult(RESULT_OK,intent);

                }
                finish();
            }
        });

        //sixth
        findViewById(R.id.avatarm3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                value = 6;
                if(value == 0 ){
                    setResult(RESULT_CANCELED);
                }else{
                    Intent intent=new Intent();
                    intent.putExtra(MainActivity.VALUE_KEY,value);
                    setResult(RESULT_OK,intent);

                }
                finish();
            }
        });

    }
}
