package com.example.inclass03;

import java.io.Serializable;

/**
 * Below is the Student class used to initiate the data recieved from the interface
 * Author : Nitin H.
 */
public class Student implements Serializable {

    int imageId;
    String firstName;
    String lastName;
    int studentId;
    String department;

    public Student(String firstName, String lastName, int studentId, String department, int imageId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.studentId = studentId;
        this.department = department;
        this.imageId = imageId;
    }
}
