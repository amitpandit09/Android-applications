package com.example.practice_midterm;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    ArrayList<String> items;
    ArrayList<String> recycleItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setIcon(R.drawable.ic_menu_overflow);
        actionBar.setDisplayShowHomeEnabled(true);



        final ListView list_View;

          items = new ArrayList<>();
         items.add("Select Anyone");
         items.add("Banana");
         items.add("Orange");
         items.add("Apple");
         items.add("Mango");
      //  EditText t1 = findViewById(R.id.enter_name);
        Spinner spinner = findViewById(R.id.spinner_fresh);

        ArrayAdapter<String> spinnerDropDown =
                new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, items);

        spinner.setAdapter(spinnerDropDown);

        String s = spinner.getSelectedItem().toString();
        Log.d("Values are",s);

        list_View = findViewById(R.id.list_view_one);
        recyclerView = findViewById(R.id.recycler_view_one);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


        recyclerView.setHasFixedSize(true);

        final ArrayAdapter<String> itemsAdapter = new ArrayAdapter<>(MainActivity.this,
                android.R.layout.simple_list_item_1, items);

        list_View.setAdapter(itemsAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Item is",items.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                String s = parent.getSelectedItem().toString();
                Log.d("Values at", s);
            }
        });

        list_View.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("POS",""+position);
                //items.remove(position);
                recycleItems.add(items.get(position));
                //items.remove(position);
                itemsAdapter.notifyDataSetChanged();
                Log.d("Values", recycleItems.toString());
                mAdapter = new MyAdapter(recycleItems);
                recyclerView.setAdapter(mAdapter);
            }
        });


    }
}
