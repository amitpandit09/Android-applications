package com.example.practice_midterm;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {


    RecyclerView recyclerView;
    ArrayList<String> items;

    public MyAdapter(ArrayList<String> input){
        this.items = input;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View freshRecycledView = LayoutInflater.from(viewGroup.getContext()).inflate(
                R.layout.my_text_view,  viewGroup, false);

        ViewHolder v = new ViewHolder(freshRecycledView);
        return v;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        String s = items.get(i);
        Log.d("Inside Recycle",s);
        viewHolder.yourChoice.setText(s);

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView yourChoice;

        public ViewHolder(final View itemView) {
            super(itemView);
            yourChoice = itemView.findViewById(R.id.sample_textView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = itemView.getContext();
                    Log.d("ItemView", yourChoice.getText().toString());
                    int position = getAdapterPosition();
                    Log.d("Print POS", ""+position);
                    remove(position);
                }
            });
        }
    }

    public void remove(int position){
        items.remove(position);
        notifyItemRemoved(position);
    }
}
